# -*- coding: utf-8 -*-

from . import hr_expense_inh
from . import account_invoice_inh